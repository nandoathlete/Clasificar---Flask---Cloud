from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import os
#from werkzeug import secure_filename
import pywt
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio
from skimage import io


#Ruta absoluta donde se almacenará la señal cargada
UPLOAD_FOLDER = os.path.abspath("./uploads/")

#Definiendo aplicación
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

#Pagina principal
@app.route('/')
def Main():
	return render_template("index.html")

#Cargando Archivo desde la pagina
@app.route("/uploader", methods=['GET', 'POST'])
def uploader():
	if request.method == "GET":
		return render_template("index.html")
	else:
		if "ourfile" not in  request.files:
			return render_template("ourfilenotin.html")
			#Obteniendo archivo desde la pagina
		signal = request.files['ourfile']
		if signal.filename == "":
			return render_template("nofile.html")		
		filename = signal.filename
		signal.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))	
		#Obteniendo el valor de Frecuencia
		Frequency = request.form["Frecuencia"]		
		#Obteniendo el valor de Ganancia
		Gain = request.form["Ganancia"]		
		#Obteniendo el valor de Base
		Base = request.form["Base"]
		if Frequency == "" or Gain == "" or Base == "":
			return render_template("novariable.html")
			
		#Seleccionando valores de derivadas
		Selection = request.form.getlist("Comp_select")	
		RR = Final(Frequency, Gain, Base, Selection, filename)
		return render_template('result.html', href = RR)

def Final(Frecuencia, Ganancia, Base, Selection, filename):
	#Cargando el modelo 
	Modelo = joblib.load("./model/Modelo.pkl")
	Frecuencia = int(Frecuencia)
	Ganancia = int(Ganancia)
	Base = int(Base)
	
	#print(Selection[0])
	#print(type(Selection[0])) # String

	#Abriendo señal cargada
	Senales = sio.loadmat("./uploads/"+filename) 
	#print(Senales)
	#Ajustando amplitud (Estandarizando la señal):
	Senal_Final = (Senales["val"] - Base)/Ganancia

	#Centrar señal en cero:
	Senal_Cero = []
	for Posicion, Valor in enumerate(Senal_Final):
	    Senal_Cero.append((Valor - np.mean(Valor))/np.std(Valor))
	Senal_Cero = np.array(Senal_Cero)
	
	#Convirtiendo a DataFrame las derivadas desglozadas:
	Senales_Derivadas = pd.DataFrame(
	    {
		 'Senal_i' : Senal_Cero[0,:15420],
		 'Senal_ii' : Senal_Cero[1,:15420],
		 'Senal_iii' : Senal_Cero[2,:15420],
		 'Senal_avr' : Senal_Cero[3,:15420],
		 'Senal_avl' : Senal_Cero[4,:15420],
		 'Senal_avf' : Senal_Cero[5,:15420],
		 'Senal_v1' : Senal_Cero[6,:15420],
		 'Senal_v2' : Senal_Cero[7,:15420],
		 'Senal_v3' : Senal_Cero[8,:15420],
		 'Senal_v4' : Senal_Cero[9,:15420],
		 'Senal_v5' : Senal_Cero[10,:15420],
		 'Senal_v6' : Senal_Cero[11,:15420],
		 'Senal_vx' : Senal_Cero[12,:15420],
		 'Senal_vy' : Senal_Cero[13,:15420],
		 'Senal_vz' : Senal_Cero[14,:15420],
		}
	)	

	##################################################
	#            LINEAS DE PROCESAMIENTO             #
	##################################################



	#--------------------------------------
	#--- Primera linea de procesamiento ---
	#--------------------------------------

	###     FFT || Entropia (Sublineas) || Concatenación varianza (100 datos) || Normalización     ###


	######################
	#        FFT         #
	######################

	Contador_fig_señales = 1
	Contador_fig_fft = Contador_fig_señales + 1
	Contador_fig_filtro = Contador_fig_señales + 2
	contador_fig_ifft = Contador_fig_señales + 3
	#Almacena las ifft en DataFrame
	Senales_ifft = pd.DataFrame()
	#Identificador del nombre de cada columna (header)
	Nombres_Columnas = Senales_Derivadas.columns
	#Recorre las posiciones de cada columna del DataFrame
	Recorrer_Columna = 0
	#Se crea lista para almacenar todas las IFFT 
	Lista_ifft = []

	for Posicion, Valor in enumerate(Senales_Derivadas):
	    # Ploteando Señales:
	    # plt.figure(Contador_fig_señales)
	    # plt.plot(Vector_Tiempo, Senales_Derivadas[Nombres_Columnas[Recorrer_Columna]])
	    # plt.title(Nombres_Columnas[Recorrer_Columna] + " - Derivadas en el Tiempo")
	    # plt.ylabel("Amplitud")
	    # plt.xlabel("Tiempo [s]")
	    # plt.xlim([0, Vector_Tiempo[-1]])
	    
	    #Aplicando FFT:
	    fft_senal = np.fft.fft(Senales_Derivadas[Valor].values)
	    #plt.figure(Contador_fig_fft)
	    #plt.plot(abs(fft_senal))
	    #plt.title(Nombres_Columnas[Recorrer_Columna] + " Derivadas en Frecuencia")
	    #plt.ylabel("Amplitud")
	    #plt.xlabel("Frecuencia [Hz]")
	    
	    #Filtrando DC:
	    fft_senal[1200:(Senales_Derivadas.shape[0]-1200)] = 0
	    #plt.figure(Contador_fig_filtro)
	    #plt.plot(abs(fft_senal))
	    #plt.title(Nombres_Columnas[Recorrer_Columna] + " Reducción de Ruido")
	    #plt.ylabel("Amplitud")
	    #plt.xlabel("Frecuencia [Hz]")
	    
	    #Aplicando IFFT:
	    ifft_senal = np.fft.ifft(fft_senal)
	    ifft_senal = ifft_senal.real
	    #plt.figure(contador_fig_ifft)
	    #plt.plot(Vector_Tiempo, ifft_senal)
	    #plt.title(Nombres_Columnas[Recorrer_Columna] + " - Inversa de las Derivadas")
	    #plt.ylabel("Amplitud")
	    #plt.xlabel("Tiempo [s]")
	    #plt.xlim([0, Vector_Tiempo[-1]])
	    
	    Contador_fig_fft += 4
	    Contador_fig_señales += 4
	    Contador_fig_filtro += 4
	    contador_fig_ifft += 4
	    Recorrer_Columna += 1
	    
	    #Agregando a la Lista las IFFT de Cada Derivada:
	    Lista_ifft.append(ifft_senal)  
	#plt.show()
	Lista_ifft = np.array(Lista_ifft)



	######################
	#      ENTROPIA      #
	######################

	#Calculando el cuadrado de cada dato de la señal
	Valor_Cuadrado= []
	for i in Lista_ifft:
	    Valor_Cuadrado.append(i**2)
	Valor_Cuadrado = np.array(Valor_Cuadrado)
	#Desglozando Derivadas (de Valor al Cuadrado)
	#para aplicar Entropia en cada derivada de forma independiente

	Senal_i = Valor_Cuadrado[0]
	Senal_ii = Valor_Cuadrado[1]
	Senal_iii = Valor_Cuadrado[2]
	Senal_avr = Valor_Cuadrado[3]
	Senal_avl = Valor_Cuadrado[4]
	Senal_avf = Valor_Cuadrado[5]
	Senal_v1 = Valor_Cuadrado[6]
	Senal_v2 = Valor_Cuadrado[7]
	Senal_v3 = Valor_Cuadrado[8]
	Senal_v4 = Valor_Cuadrado[9]
	Senal_v5 = Valor_Cuadrado[10]
	Senal_v6 = Valor_Cuadrado[11]
	Senal_vx = Valor_Cuadrado[12]
	Senal_vy = Valor_Cuadrado[13]
	Senal_vz = Valor_Cuadrado[14]	
	
	#      Sublinea 3      #



	#...................
	#.. Para Señal i  ..
	#...................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_i = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_i):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_i.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_i):
			break       
	Entropia_i = pd.DataFrame({'Senal_i' : Entropia_i})
	Entropia_i = Entropia_i.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_i_norm = []
	#Normalizando Sublinea 3 Entropia Señal i
	for Posicion, Valor in enumerate(Entropia_i):
		Entropia_i_norm.append((Entropia_i[Valor] - min(Entropia_i[Valor]))/(max(Entropia_i[Valor]) - min(Entropia_i[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_i_norm = np.array(Entropia_i_norm) 

	Varianza = np.std(Entropia_i_norm)
	for gg in range(0,100):
	    Entropia_i_norm = np.append(Entropia_i_norm, [[Varianza] for i in range(len(Entropia_i_norm))], axis=1)

	#....................
	#.. Para Señal ii  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_ii = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_ii):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_ii.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_ii):
			break       
	Entropia_ii = pd.DataFrame({'Senal_ii' : Entropia_ii})
	Entropia_ii = Entropia_ii.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_ii_norm = []
	#Normalizando Sublinea 3 Entropia Señal ii
	for Posicion, Valor in enumerate(Entropia_ii):
		Entropia_ii_norm.append((Entropia_ii[Valor] - min(Entropia_ii[Valor]))/(max(Entropia_ii[Valor]) - min(Entropia_ii[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_ii_norm = np.array(Entropia_ii_norm) 

	Varianza = np.std(Entropia_ii_norm)
	for gg in range(0,100):
	    Entropia_ii_norm = np.append(Entropia_ii_norm, [[Varianza] for i in range(len(Entropia_ii_norm))], axis=1)

	#.....................
	#.. Para Señal iii  ..
	#.....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_iii = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_iii):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_iii.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_iii):
			break       
	Entropia_iii = pd.DataFrame({'Senal_iii' : Entropia_iii})
	Entropia_iii = Entropia_iii.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_iii_norm = []
	#Normalizando Sublinea 3 Entropia Señal iii
	for Posicion, Valor in enumerate(Entropia_iii):
		Entropia_iii_norm.append((Entropia_iii[Valor] - min(Entropia_iii[Valor]))/(max(Entropia_iii[Valor]) - min(Entropia_iii[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_iii_norm = np.array(Entropia_iii_norm) 

	Varianza = np.std(Entropia_iii_norm)
	for gg in range(0,100):
	    Entropia_iii_norm = np.append(Entropia_iii_norm, [[Varianza] for i in range(len(Entropia_iii_norm))], axis=1)

	#.....................
	#.. Para Señal avr  ..
	#.....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_avr = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_avr):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_avr.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_avr):
			break       
	Entropia_avr = pd.DataFrame({'Senal_avr' : Entropia_avr})
	Entropia_avr = Entropia_avr.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_avr_norm = []
	#Normalizando Sublinea 3 Entropia Señal avr
	for Posicion, Valor in enumerate(Entropia_avr):
		Entropia_avr_norm.append((Entropia_avr[Valor] - min(Entropia_avr[Valor]))/(max(Entropia_avr[Valor]) - min(Entropia_avr[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_avr_norm = np.array(Entropia_avr_norm) 

	Varianza = np.std(Entropia_avr_norm)
	for gg in range(0,100):
	    Entropia_avr_norm = np.append(Entropia_avr_norm, [[Varianza] for i in range(len(Entropia_avr_norm))], axis=1)

	#.....................
	#.. Para Señal avl  ..
	#.....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_avl = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_avl):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_avl.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_avl):
			break       
	Entropia_avl = pd.DataFrame({'Senal_avl' : Entropia_avl})
	Entropia_avl = Entropia_avl.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_avl_norm = []
	#Normalizando Sublinea 3 Entropia Señal avl
	for Posicion, Valor in enumerate(Entropia_avl):
		Entropia_avl_norm.append((Entropia_avl[Valor] - min(Entropia_avl[Valor]))/(max(Entropia_avl[Valor]) - min(Entropia_avl[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_avl_norm = np.array(Entropia_avl_norm) 

	Varianza = np.std(Entropia_avl_norm)
	for gg in range(0,100):
	    Entropia_avl_norm = np.append(Entropia_avl_norm, [[Varianza] for i in range(len(Entropia_avl_norm))], axis=1)

	#.....................
	#.. Para Señal avf  ..
	#.....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_avf = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_avf):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_avf.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_avf):
			break       
	Entropia_avf = pd.DataFrame({'Senal_avf' : Entropia_avf})
	Entropia_avf = Entropia_avf.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_avf_norm = []
	#Normalizando Sublinea 3 Entropia Señal avf
	for Posicion, Valor in enumerate(Entropia_avf):
		Entropia_avf_norm.append((Entropia_avf[Valor] - min(Entropia_avf[Valor]))/(max(Entropia_avf[Valor]) - min(Entropia_avf[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_avf_norm = np.array(Entropia_avf_norm) 

	Varianza = np.std(Entropia_avf_norm)
	for gg in range(0,100):
	    Entropia_avf_norm = np.append(Entropia_avf_norm, [[Varianza] for i in range(len(Entropia_avf_norm))], axis=1)

	#....................
	#.. Para Señal v1  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_v1 = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_v1):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_v1.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_v1):
			break       
	Entropia_v1 = pd.DataFrame({'Senal_v1' : Entropia_v1})
	Entropia_v1 = Entropia_v1.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_v1_norm = []
	#Normalizando Sublinea 3 Entropia Señal v1
	for Posicion, Valor in enumerate(Entropia_v1):
		Entropia_v1_norm.append((Entropia_v1[Valor] - min(Entropia_v1[Valor]))/(max(Entropia_v1[Valor]) - min(Entropia_v1[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_v1_norm = np.array(Entropia_v1_norm) 

	Varianza = np.std(Entropia_v1_norm)
	for gg in range(0,100):
	    Entropia_v1_norm = np.append(Entropia_v1_norm, [[Varianza] for i in range(len(Entropia_v1_norm))], axis=1)

	#....................
	#.. Para Señal v2  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_v2 = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_v2):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_v2.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_v2):
			break       
	Entropia_v2 = pd.DataFrame({'Senal_v2' : Entropia_v2})
	Entropia_v2 = Entropia_v2.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_v2_norm = []
	#Normalizando Sublinea 3 Entropia Señal v2
	for Posicion, Valor in enumerate(Entropia_v2):
		Entropia_v2_norm.append((Entropia_v2[Valor] - min(Entropia_v2[Valor]))/(max(Entropia_v2[Valor]) - min(Entropia_v2[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_v2_norm = np.array(Entropia_v2_norm) 

	Varianza = np.std(Entropia_v2_norm)
	for gg in range(0,100):
	    Entropia_v2_norm = np.append(Entropia_v2_norm, [[Varianza] for i in range(len(Entropia_v2_norm))], axis=1)

	#....................
	#.. Para Señal v3  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_v3 = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_v3):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_v3.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_v3):
			break       
	Entropia_v3 = pd.DataFrame({'Senal_v3' : Entropia_v3})
	Entropia_v3 = Entropia_v3.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_v3_norm = []
	#Normalizando Sublinea 3 Entropia Señal v3
	for Posicion, Valor in enumerate(Entropia_v3):
		Entropia_v3_norm.append((Entropia_v3[Valor] - min(Entropia_v3[Valor]))/(max(Entropia_v3[Valor]) - min(Entropia_v3[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_v3_norm = np.array(Entropia_v3_norm) 

	Varianza = np.std(Entropia_v3_norm)
	for gg in range(0,100):
	    Entropia_v3_norm = np.append(Entropia_v3_norm, [[Varianza] for i in range(len(Entropia_v3_norm))], axis=1)

	#....................
	#.. Para Señal v4  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_v4 = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_v4):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_v4.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_v4):
			break       
	Entropia_v4 = pd.DataFrame({'Senal_v4' : Entropia_v4})
	Entropia_v4 = Entropia_v4.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_v4_norm = []
	#Normalizando Sublinea 3 Entropia Señal v4
	for Posicion, Valor in enumerate(Entropia_v4):
		Entropia_v4_norm.append((Entropia_v4[Valor] - min(Entropia_v4[Valor]))/(max(Entropia_v4[Valor]) - min(Entropia_v4[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_v4_norm = np.array(Entropia_v4_norm) 

	Varianza = np.std(Entropia_v4_norm)
	for gg in range(0,100):
	    Entropia_v4_norm = np.append(Entropia_v4_norm, [[Varianza] for i in range(len(Entropia_v4_norm))], axis=1)

	#....................
	#.. Para Señal v5  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_v5 = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_v5):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_v5.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_v5):
			break       
	Entropia_v5 = pd.DataFrame({'Senal_v5' : Entropia_v5})
	Entropia_v5 = Entropia_v5.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_v5_norm = []
	#Normalizando Sublinea 3 Entropia Señal v5
	for Posicion, Valor in enumerate(Entropia_v5):
		Entropia_v5_norm.append((Entropia_v5[Valor] - min(Entropia_v5[Valor]))/(max(Entropia_v5[Valor]) - min(Entropia_v5[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_v5_norm = np.array(Entropia_v5_norm) 

	Varianza = np.std(Entropia_v5_norm)
	for gg in range(0,100):
	    Entropia_v5_norm = np.append(Entropia_v5_norm, [[Varianza] for i in range(len(Entropia_v5_norm))], axis=1)

	#....................
	#.. Para Señal v6  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_v6 = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_v6):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_v6.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_v6):
			break       
	Entropia_v6 = pd.DataFrame({'Senal_v6' : Entropia_v6})
	Entropia_v6 = Entropia_v6.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_v6_norm = []
	#Normalizando Sublinea 3 Entropia Señal v6
	for Posicion, Valor in enumerate(Entropia_v6):
		Entropia_v6_norm.append((Entropia_v6[Valor] - min(Entropia_v6[Valor]))/(max(Entropia_v6[Valor]) - min(Entropia_v6[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_v6_norm = np.array(Entropia_v6_norm) 

	Varianza = np.std(Entropia_v6_norm)
	for gg in range(0,100):
	    Entropia_v6_norm = np.append(Entropia_v6_norm, [[Varianza] for i in range(len(Entropia_v6_norm))], axis=1)

	#....................
	#.. Para Señal vx  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_vx = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_vx):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_vx.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_vx):
			break       
	Entropia_vx = pd.DataFrame({'Senal_vx' : Entropia_vx})
	Entropia_vx = Entropia_vx.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_vx_norm = []
	#Normalizando Sublinea 3 Entropia Señal vx
	for Posicion, Valor in enumerate(Entropia_vx):
		Entropia_vx_norm.append((Entropia_vx[Valor] - min(Entropia_vx[Valor]))/(max(Entropia_vx[Valor]) - min(Entropia_vx[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_vx_norm = np.array(Entropia_vx_norm) 

	Varianza = np.std(Entropia_vx_norm)
	for gg in range(0,100):
	    Entropia_vx_norm = np.append(Entropia_vx_norm, [[Varianza] for i in range(len(Entropia_vx_norm))], axis=1)

	#....................
	#.. Para Señal vy  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_vy = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_vy):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_vy.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_vy):
			break       
	Entropia_vy = pd.DataFrame({'Senal_vy' : Entropia_vy})
	Entropia_vy = Entropia_vy.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_vy_norm = []
	#Normalizando Sublinea 3 Entropia Señal vy
	for Posicion, Valor in enumerate(Entropia_vy):
		Entropia_vy_norm.append((Entropia_vy[Valor] - min(Entropia_vy[Valor]))/(max(Entropia_vy[Valor]) - min(Entropia_vy[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_vy_norm = np.array(Entropia_vy_norm) 

	Varianza = np.std(Entropia_vy_norm)
	for gg in range(0,100):
	    Entropia_vy_norm = np.append(Entropia_vy_norm, [[Varianza] for i in range(len(Entropia_vy_norm))], axis=1)

	#....................
	#.. Para Señal vz  ..
	#....................
	#Ventaneo 30% -> 30 datos por ventana (Un total de 513 puntos)

	Ventana = 30
	Entropia_vz = []
	Entropia = 0
	for Posicion, Valor in enumerate(Senal_vz):
		Entropia += Valor*(np.log2(Valor))
		if Posicion == Ventana:
			Entropia_vz.append(Entropia)
			Entropia = 0
			Ventana += 30
		if Posicion == len(Senal_vz):
			break       
	Entropia_vz = pd.DataFrame({'Senal_vz' : Entropia_vz})
	Entropia_vz = Entropia_vz.fillna(0)
	#Lista para agregar las señales normalizadas
	Entropia_vz_norm = []
	#Normalizando Sublinea 3 Entropia Señal vz
	for Posicion, Valor in enumerate(Entropia_vz):
		Entropia_vz_norm.append((Entropia_vz[Valor] - min(Entropia_vz[Valor]))/(max(Entropia_vz[Valor]) - min(Entropia_vz[Valor])))
	# Convirtiendo a Array para poder pasar DataFrame después
	Entropia_vz_norm = np.array(Entropia_vz_norm) 

	Varianza = np.std(Entropia_vz_norm)
	for gg in range(0,100):
	    Entropia_vz_norm = np.append(Entropia_vz_norm, [[Varianza] for i in range(len(Entropia_vz_norm))], axis=1)

	Linea_1_Sublinea_3 = pd.DataFrame(
		{
			'Senal_i' : Entropia_i_norm[0,:],
			'Senal_ii' : Entropia_ii_norm[0,:],
			'Senal_iii' : Entropia_iii_norm[0,:],
			'Senal_avr' : Entropia_avr_norm[0,:],
			'Senal_avl' : Entropia_avl_norm[0,:],
			'Senal_avf' : Entropia_avf_norm[0,:],
			'Senal_v1' : Entropia_v1_norm[0,:],
			'Senal_v2' : Entropia_v2_norm[0,:],
			'Senal_v3' : Entropia_v3_norm[0,:],
			'Senal_v4' : Entropia_v4_norm[0,:],
			'Senal_v5' : Entropia_v5_norm[0,:],
			'Senal_v6' : Entropia_v6_norm[0,:],
			'Senal_vx' : Entropia_vx_norm[0,:],
			'Senal_vy' : Entropia_vy_norm[0,:],
			'Senal_vz' : Entropia_vz_norm[0,:],
		}
	)
	#Reemplazando Valores Nulos (NaN) por Cero (0)
	Linea_1_Sublinea_3 = Linea_1_Sublinea_3.fillna(0)	
	
	V = Selection
	if V[0]=='i':
		Derivada = 0
	if V[0]=='ii':
		Derivada = 1
	if V[0]=='iii':
		Derivada = 2
	if V[0]=='avr':
		Derivada = 3
	if V[0]=='avl':
		Derivada = 4
	if V[0]=='avf':
		Derivada = 5
	if V[0]=='v1':
		Derivada = 6
	if V[0]=='v2':
		Derivada = 7
	if V[0]=='v3':
		Derivada = 8
	if V[0]=='v4':
		Derivada = 9
	if V[0]=='v5':
		Derivada = 10
	if V[0]=='v6':
		Derivada = 11
	if V[0]=='vx':
		Derivada = 12
	if V[0]=='vy':
		Derivada = 13
	if V[0]=='vz':
		Derivada = 14
	########################################################################
	#                             CLASIFICACIÓN                            #
	########################################################################
	
	#Obtiene la posición de la derivada a clasificar

	if V[0]=='i' or V[0]=='ii' or V[0]=='iii' or V[0]=='avr' or V[0]=='avl' or V[0]=='avf' or V[0]=='v1' or V[0]=='v2' or V[0]=='v3' or V[0]=='v4' or V[0]=='v5' or V[0]=='v6' or V[0]=='vx' or V[0]=='vy' or V[0]=='vz':
		
		######      Cargando Modelo de Entrenamiento      ######
		Paciente = Linea_1_Sublinea_3.values
		Paciente = Paciente.T
		Paciente = Paciente[Derivada,:]
		Paciente = Paciente[np.newaxis,:]
		y_pred = Modelo.predict(Paciente)
		y_pred = int(y_pred)
	
	return y_pred
			
			
			
		



if __name__ == '__main__':
	app.run(debug = True)
	

	
"""
@app.route("/uploads/filename")
def get_file(filename[3]):


	return "Hola"
	#return send_from_directory(app.config["UPLOAD_FOLDER"], filename)
"""
	
